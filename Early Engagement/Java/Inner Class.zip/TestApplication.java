import java.util.*;
public class TestApplication {

	public static void main(String[] args)
	{
	    AddressBook a1 = new AddressBook();
	    AddressBook.Address a = a1.new Address();
	    AddressBook.Address b = a1.new Address();
	    Scanner sc = new Scanner(System.in);
	    String hn,st,c,stat;
	    long ph;
	    System.out.println("Enter the permanent address");
	    System.out.println("Enter the house name");
	    hn = sc.nextLine();
	    a.setName(hn);
	    System.out.println("Enter the street");
	    st = sc.nextLine();
	    a.setStreet(st);
	    System.out.println("Enter the city");
	    c = sc.nextLine();
	    a.setCity(c);
	    System.out.println("Enter the state");
	    stat = sc.nextLine();
	    a.setState(stat);
	    a1.setPermAddress(a);
	    
	    System.out.println("Enter the temporary address");
	    System.out.println("Enter the house name");
	    hn = sc.nextLine();
	    b.setName(hn);
	    System.out.println("Enter the street");
	    st = sc.nextLine();
	    b.setStreet(st);
	    System.out.println("Enter the city");
	    c = sc.nextLine();
	    b.setCity(c);
	    System.out.println("Enter the state");
	    stat = sc.nextLine();
	    b.setState(stat);
	    a1.setTempAddress(b);
	    
	    System.out.println("Enter the phone number");
	    ph = sc.nextLong();
	    a1.setPhoneNumber(ph);
	    
	    System.out.println("Permanent address");
        a = a1.getPermAddress();
        System.out.println("House name:"+a.getName());
        System.out.println("Street:"+a.getStreet());
        System.out.println("City:"+a.getCity());
        System.out.println("State:"+a.getState());
        
        System.out.println("Temporary address");
        b = a1.getTempAddress();
        System.out.println("House name:"+b.getName());
        System.out.println("Street:"+b.getStreet());
        System.out.println("City:"+b.getCity());
        System.out.println("State:"+b.getState());
        
        System.out.println("Phone number");
        System.out.println(a1.getPhoneNumber());
	}
}