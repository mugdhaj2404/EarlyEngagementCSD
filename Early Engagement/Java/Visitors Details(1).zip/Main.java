//import necessary packages
import java.util.*;
import java.io.*;

 @SuppressWarnings("unchecked")//Do not delete this line
public class Main
{
	public static void main(String[] args) 
	{
	    
	    
	    FileManager fl=new FileManager();
	    File f=fl.createFile();
	    int i1=1;
	    do 
	    {
	        /*String name;
	    String phone_no;
	    String email;
	    String tr="";*/
	    Scanner sc=new Scanner(System.in);
	    
    	    System.out.println("Enter Name");
    	    String name=sc.nextLine();
    	    
    	    System.out.println("Enter Phone Number");
    	    String phone_no=sc.nextLine();
    	    
    	    System.out.println("Enter Email");
    	    String email=sc.nextLine();
    	    
    	    System.out.println("Do you want to enter another record(yes/no)");
    	    String result=sc.next();
    	    String tr=name+","+phone_no+","+email+";";
    	    
    	    fl.writeFile(f,tr);
    	    
    	    if(result.equals("yes"))
    	    {
    	        i1=1;
    	    }
    	    else
    	    {
    	        i1=0;
    	    }
    	    
    	    
    	    
	    }while(i1==1);
	    
	    
	    String st1[]=fl.readFile(f);
	    
	    
	    //String st=st1[0];
	    
	    
	   // String[] rc=st.split(";");
	    
	    
	    for(String s:st1)
	    {
	        System.out.println(s);
	    }
	    
	    
	    
	    
	    
	}
    
}