 //import necessary packages
 import java.io.FileWriter;  
 //import java.io.File; 
 import java.io.*;

import java.io.IOException;

 @SuppressWarnings("unchecked")//Do not delete this line
 public class FileManager 
 {
    
    static public File createFile()
    {
            File f = new File("visitors.txt");
    
        try {
        
        f.createNewFile();
        
            
        } catch(Exception e) 
        {
            
        } finally {
        }
        return f;//change the return type as per the requirement    
    }
    static public void writeFile(File f, String record)
	{
	    try{
	    //FileWriter fw=new FileWriter("visitors.txt",true);  
	    BufferedWriter writer = new BufferedWriter(
                                new FileWriter("visitors.txt", true)  //Set true for append mode
                            );  
    
    //writer.newLine();
    writer.append(record);
    writer.close();
	    }
	    catch(Exception e){
	        
	    }
	    
	} 
	static public String[] readFile(File f)
	{String st,bc="";
	    
	    try{
	    BufferedReader br = new BufferedReader(new FileReader(f)); 
             
  
  
  
                  while ((st = br.readLine()) != null)
                  {
                    bc=bc+st;
                   // System.out.println(st);
                  }
                  
                  br.close();
	    }
	    catch(Exception e)
	    {
	        
	    }
	    
  	    
	    
	    String[] st1=bc.split(";");
	    return st1;//change the return type as per the requirement  
	}
 }