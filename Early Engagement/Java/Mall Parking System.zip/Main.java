import java.util.*;
import java.text.SimpleDateFormat;
public class Main 
{

    public static void main(String [] args) 
    {
        //Fill the Code
        int flag=0;
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        String inTime="",outTime="",curr = "29/10/2019 20:10";
        try
        {
        Scanner sc = new Scanner(System.in);
        //String inTime,outTime,curr = "29/10/2019 20:10";
        Date d1 = sdf.parse(curr);
        flag=1;
        System.out.println("In-time");
        inTime = sc.nextLine();
        Date d2 = sdf.parse(inTime);
        long diff = d1.getTime() - d2.getTime();
        long min = diff/(60*1000)%60;
        if(min<1)
        {
            System.out.println(inTime+" is an Invalid In-Time");
            System.exit(0);
        }
        flag=0;
        System.out.println("Out-time");
        outTime = sc.nextLine();
        Date d3 = sdf.parse(outTime);
        diff = d3.getTime() - d2.getTime();
        min = diff/(60*1000)%60;
        if(min<1)
        {
            System.out.println(outTime+" is an Invalid Out-Time");
            System.exit(0);
        }
        diff = d3.getTime() - d2.getTime();
        min = diff/(60*60*1000);
        if(min==0)
        {
            System.out.println("10 Rupees");
        }
        else
        {
             long ans = (min+1)*10;
            System.out.println(ans+" Rupees");
        }
        }
        catch(Exception e)
        {
            if(flag==1)
            {
                System.out.println(inTime+" is an Invalid In-Time");
            }
            else
            {
                System.out.println(outTime+" is an Invalid Out-Time");
            }
        }
    }
}