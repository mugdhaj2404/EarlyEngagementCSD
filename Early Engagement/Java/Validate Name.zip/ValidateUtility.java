import java.util.*;
public class ValidateUtility 
{
 
    public static void main(String args[])
    {
       Scanner sc = new Scanner(System.in);
       String s1,s2;
       s1 = sc.nextLine();
       //sc.nextLine();
       s2 = sc.nextLine();
       //ValidateUtility v = new ValidateUtility();
       Validate v1 = validateEmployeeName();
      // boolean a = v3.validateName(s1);
       if(v1.validateName(s1))
       System.out.println("Employee name is valid");
       else
       System.out.println("Employee name is invalid");
       
       Validate v2 = validateProductName();
     //  boolean b = v4.validateName(s2);
       if(v2.validateName(s2))
       System.out.println("Product name is valid");
       else
       System.out.println("Product name is invalid");
    }
    
    public static Validate validateEmployeeName() 
    {
        //fill code here
        Validate v1 = (s1)->
        {
           int cntr=0;
           for(int i=0;i<s1.length();i++)
           {
               char c = s1.charAt(i);
               int j=c;
               if(j>=65 && j<=90 || j>=97 && j<=122 || j==32)
               {
                   if(j!=32)
                   cntr++;
               }
               else
               {
                   return false;
               }
           }
           if(cntr<5 || cntr>20)
           {
               return false;
           }
           else
             return true;
        };
        return v1;
    }
    
    public static Validate validateProductName()
    {
       Validate v2 = (s2)->
       {
         if(s2.length()==6)
         {
           if(s2.matches("^[A-Za-z]+([0-9]{5})$"))
           {
               return true;
           }
           else
           {
               return false;
           }
         }
        else
        return false;
       };
       return v2;
    }
    
    
}



