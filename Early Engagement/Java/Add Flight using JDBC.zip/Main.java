import java.util.*;
public class Main{
    public static void main(String[] args)
    {
        int id,noofseats;
        double fare;
        String source,destination;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the flight ID");
        id = sc.nextInt();
        System.out.println("Enter the source");
        source = sc.next();
        System.out.println("Enter the destination");
        destination = sc.next();
        System.out.println("Enter the number of seats");
        noofseats = sc.nextInt();
        System.out.println("Enter the flight fare");
        fare = sc.nextDouble();
        Flight f = new Flight(id,source,destination,noofseats,fare);
        FlightManagementSystem fms = new FlightManagementSystem();
        if(fms.addFlight(f))
        {
            System.out.println("Flight details added successfully");   
        }
        else
        {
            System.out.println("Addition not done");
        }
    }
}