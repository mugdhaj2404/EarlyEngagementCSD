import java.io.*;
import java.sql.*;
public class FlightManagementSystem
{
    private static Connection con = null;
    public boolean addFlight(Flight flightObj)
    {
        try
        {
       
        int id,noofseats;
        String source,destination;
        double fare;
        id = flightObj.getFlightId();
        source = flightObj.getSource();
        destination = flightObj.getDestination();
        noofseats = flightObj.getNoOfSeats();
        fare = flightObj.getFlightFare();
        con = DB.getConnection();
        PreparedStatement stmt = con.prepareStatement("insert into flight values(?,?,?,?,?)");
        stmt.setInt(1,id);
        stmt.setString(2,source);
        stmt.setString(3,destination);
        stmt.setInt(4,noofseats);
        stmt.setDouble(5,fare);
        int i = stmt.executeUpdate();
        con.close();
        return true;
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
            return false;
        }
        
    }
}